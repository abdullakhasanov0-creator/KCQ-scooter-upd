package com.kcqconnect.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kcqconnect.app.ui.KcqRoot
import com.kcqconnect.app.ui.KcqTheme
import com.kcqconnect.app.ui.MainViewModel
import com.kcqconnect.app.ui.ThemeState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeState.load(applicationContext)
        setContent {
            KcqTheme {
                val vm: MainViewModel = viewModel()
                KcqRoot(vm)
            }
        }
    }
}
