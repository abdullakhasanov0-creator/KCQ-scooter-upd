package com.kcqconnect.app.diagnostics

import android.util.Log
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class DiagnosticsLog {
    private val fmt = DateTimeFormatter.ofPattern("HH:mm:ss.SSS")
    private val _entries = MutableStateFlow<List<String>>(emptyList())
    val entries: StateFlow<List<String>> = _entries.asStateFlow()

    fun add(level: String, message: String) {
        val line = "${LocalTime.now().format(fmt)} [$level] $message"
        Log.d("KCQ", line)
        _entries.update { (it + line).takeLast(MAX) }
    }

    fun clear() {
        _entries.value = emptyList()
    }

    private companion object {
        const val MAX = 300
    }
}
