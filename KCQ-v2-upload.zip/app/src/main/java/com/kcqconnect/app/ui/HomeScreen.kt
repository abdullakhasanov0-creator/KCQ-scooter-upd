package com.kcqconnect.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import android.content.Intent
import android.provider.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kcqconnect.app.bluetooth.ConnectionState

private const val FRESH_MS = 3_000L
private const val NO_DATA = "Нет данных"

@Composable
fun HomeScreen(vm: MainViewModel, onScan: () -> Unit) {
    val context = LocalContext.current
    val conn = vm.connection
    val state by conn.state.collectAsState()
    val btOn by vm.btMonitor.enabled.collectAsState()
    val telemetry by conn.telemetry.collectAsState()
    val lastData by conn.lastDataTime.collectAsState()
    val deviceName by conn.deviceName.collectAsState()
    val error by conn.error.collectAsState()
    val lastAddress by conn.lastAddress.collectAsState()
    val adapterName by conn.adapterName.collectAsState()
    val now by vm.now.collectAsState()

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res -> if (res.values.all { it }) vm.reconnect() }

    val fresh = lastData?.let { now - it < FRESH_MS } == true
    val data = if (fresh) telemetry else null

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HeaderRow(connected = state == ConnectionState.CONNECTED, onDisconnect = { vm.disconnect() })

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            StatusDot(if (btOn) "Bluetooth вкл" else "Bluetooth выкл", if (btOn) Ok else Bad)
            val (txt, col) = when (state) {
                ConnectionState.CONNECTED -> "Подключён" to Ok
                ConnectionState.CONNECTING, ConnectionState.DISCOVERING -> "Подключение…" to Warn
                ConnectionState.ERROR -> "Ошибка" to Bad
                ConnectionState.DISCONNECTED -> "Не подключён" to Bad
            }
            StatusDot(txt, col)
        }

        when (state) {
            ConnectionState.CONNECTED -> {
                Text(deviceName ?: "Самокат", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Dashboard(data)
                if (adapterName == null) {
                    InfoCard("Протокол этого самоката не распознан. Откройте «Диагностику», нажмите «Экспорт TXT» и отправьте отчёт — по нему подключим показатели.")
                } else if (!fresh) {
                    InfoCard("Самокат пока не присылает данные. Показатели появятся, как только придут пакеты.")
                }
                ControlsSection()
            }
            ConnectionState.CONNECTING, ConnectionState.DISCOVERING -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Graphite),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = Cyan)
                        Text(
                            if (state == ConnectionState.CONNECTING) "Подключение к ${deviceName ?: "самокату"}…"
                            else "Чтение сервисов самоката…"
                        )
                        OutlinedButton(onClick = { vm.disconnect() }) { Text("Отмена") }
                    }
                }
            }
            else -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Graphite),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Самокат не подключён", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Включите самокат и закройте оригинальное приложение KCQ Scooter — самокат принимает только одно подключение.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (error != null) Text(error ?: "", color = Bad)
                        if (!btOn) {
                            Text("Bluetooth выключен. Включите его, чтобы продолжить.", color = Warn)
                            OutlinedButton(
                                onClick = { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Открыть настройки Bluetooth") }
                        }
                        Button(
                            onClick = onScan,
                            enabled = btOn,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = MaterialTheme.colorScheme.onPrimary)
                        ) { Text("Найти самокат") }
                        if (lastAddress != null) {
                            OutlinedButton(
                                onClick = {
                                    if (context.hasBlePermissions()) vm.reconnect()
                                    else permLauncher.launch(requiredBlePermissions())
                                },
                                enabled = btOn,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Переподключиться") }
                        }
                    }
                }
                Dashboard(null)
            }
        }
    }
}

@Composable
private fun StatusDot(text: String, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Dashboard(data: com.kcqconnect.app.protocol.Telemetry?) {
    val target = (data?.speedKmh ?: 0.0).toFloat()
    val shown by animateFloatAsState(target, tween(300), label = "speed")

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (data != null) String.format("%.1f", shown) else "—",
                fontSize = 88.sp,
                fontWeight = FontWeight.Bold,
                color = if (data != null) Cyan else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                if (data != null) "км/ч" else NO_DATA,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Заряд", data?.batteryPercent?.let { "$it %" } ?: NO_DATA, Modifier.weight(1f))
        Metric("Напряжение", NO_DATA, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Поездка", data?.let { String.format("%.1f км", it.tripKm) } ?: NO_DATA, Modifier.weight(1f))
        Metric("Общий пробег", data?.let { String.format("%.1f км", it.totalKm) } ?: NO_DATA, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Metric("Температура", NO_DATA, Modifier.weight(1f))
        Metric("Режим езды", NO_DATA, Modifier.weight(1f))
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(
                value,
                fontSize = if (value == NO_DATA) 15.sp else 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (value == NO_DATA) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun InfoCard(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GraphiteLight),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(text, Modifier.padding(14.dp), fontSize = 14.sp, color = Warn)
    }
}
