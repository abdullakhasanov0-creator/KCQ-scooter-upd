package com.kcqconnect.app.protocol

import java.util.UUID

/** Декодированные показатели. Всё, чего нет в пакете, здесь отсутствует (UI показывает «Нет данных»). */
data class Telemetry(
    val speedKmh: Double,
    val tripKm: Double,
    val totalKm: Double,
    val batteryPercent: Int?,
    val faultByte: Int,
    val statusByte: Int
)

sealed class DecodeResult {
    data class Ok(val telemetry: Telemetry) : DecodeResult()
    data class Ignored(val reason: String) : DecodeResult()
    data class Error(val reason: String) : DecodeResult()
}

/** Адаптер протокола для конкретного семейства контроллеров. */
interface ScooterAdapter {
    val id: String
    val displayName: String
    val serviceUuid: UUID
    val notifyUuid: UUID
    fun decode(bytes: ByteArray): DecodeResult
}

fun uuid16(short: Int): UUID =
    UUID.fromString(String.format("0000%04X-0000-1000-8000-00805F9B34FB", short))

fun ByteArray.toHex(): String = joinToString(" ") { String.format("%02X", it) }
