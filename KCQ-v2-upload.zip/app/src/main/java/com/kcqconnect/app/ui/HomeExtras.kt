package com.kcqconnect.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val NEED_CMD =
    "Приложение пока только читает данные. Для этой функции нужна команда записи из оригинального " +
        "приложения. Неизвестные байты в контроллер я не отправляю. Как получить команды — см. инструкцию в чате."

/** Верхняя строка: название слева, меню «⋮» справа. Редкие пункты спрятаны в меню. */
@Composable
fun HeaderRow(connected: Boolean, onDisconnect: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            "KCQ CONNECT", color = Cyan, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 2.sp, modifier = Modifier.weight(1f)
        )
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Меню") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Тема: ${ThemeState.mode.title}") }, onClick = { menu = false; dialog = "theme" })
                DropdownMenuItem(text = { Text("Лимит скорости") }, onClick = { menu = false; dialog = "need" })
                DropdownMenuItem(text = { Text("Прошивка") }, onClick = { menu = false; dialog = "need" })
                DropdownMenuItem(text = { Text("О приложении") }, onClick = { menu = false; dialog = "about" })
                if (connected) DropdownMenuItem(text = { Text("Отключиться") }, onClick = { menu = false; onDisconnect() })
            }
        }
    }

    when (dialog) {
        "theme" -> AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Закрыть") } },
            title = { Text("Тема") },
            text = {
                Column {
                    ThemeMode.values().forEach { m ->
                        Row(
                            Modifier.fillMaxWidth().clickable { ThemeState.set(ctx, m) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = ThemeState.mode == m, onClick = { ThemeState.set(ctx, m) })
                            Text(m.title)
                        }
                    }
                }
            }
        )
        "need" -> InfoDialog("Нужна команда", NEED_CMD) { dialog = null }
        "about" -> InfoDialog("KCQ CONNECT", "Версия 0.2.0 (этап 2). Чтение телеметрии, диагностика, темы.") { dialog = null }
    }
}

@Composable
private fun InfoDialog(title: String, text: String, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Понятно") } },
        title = { Text(title) },
        text = { Text(text) }
    )
}

/** Плитки управления. Пока команд записи нет — нажатие объясняет, чего не хватает. */
@Composable
fun ControlsSection() {
    var dialog by remember { mutableStateOf(false) }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Tile("💡", "Передний фонарь", Modifier.weight(1f)) { dialog = true }
        Tile("🔴", "Задний фонарь", Modifier.weight(1f)) { dialog = true }
        Tile("🔒", "Блокировка", Modifier.weight(1f)) { dialog = true }
    }
    if (dialog) InfoDialog("Нужна команда", NEED_CMD) { dialog = false }
}

@Composable
private fun Tile(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 26.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
