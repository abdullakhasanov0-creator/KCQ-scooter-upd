package com.kcqconnect.app.ui

import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.os.Build
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kcqconnect.app.bluetooth.BleConnection
import com.kcqconnect.app.bluetooth.BleScanner
import com.kcqconnect.app.bluetooth.BluetoothStateMonitor
import com.kcqconnect.app.bluetooth.ScannedDevice
import com.kcqconnect.app.diagnostics.DiagnosticsLog
import com.kcqconnect.app.diagnostics.DiagnosticsSnapshot
import com.kcqconnect.app.diagnostics.ReportBuilder
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val log = DiagnosticsLog()
    private val btAdapter: BluetoothAdapter? =
        app.getSystemService(BluetoothManager::class.java)?.adapter
    val btMonitor = BluetoothStateMonitor(app, btAdapter)
    val scanner = BleScanner({ btAdapter }, log, viewModelScope)
    val connection = BleConnection(app, { btAdapter }, log, viewModelScope)

    /** Тикает раз в секунду — нужно, чтобы понять, что данные «устарели». */
    val now: StateFlow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(1000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), System.currentTimeMillis())

    init {
        log.add("INFO", "Приложение запущено. BLE: ${if (btMonitor.supported) "есть" else "нет"}, Bluetooth: ${if (btMonitor.enabled.value) "вкл" else "выкл"}")
    }

    fun connect(d: ScannedDevice) {
        scanner.stop()
        connection.connect(d.address, d.name)
    }

    fun reconnect() = connection.reconnect()

    fun disconnect() = connection.disconnect()

    fun sendRaw(bytes: ByteArray) = connection.sendRaw(bytes)

    private fun snapshot() = DiagnosticsSnapshot(
        appVersion = "KCQ CONNECT 0.1.0",
        androidInfo = "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        btSupported = btMonitor.supported,
        btEnabled = btMonitor.enabled.value,
        connState = connection.state.value,
        deviceName = connection.deviceName.value,
        address = connection.address.value,
        adapterName = connection.adapterName.value,
        services = connection.services.value,
        lastRaw = connection.lastRaw.value,
        lastDataTime = connection.lastDataTime.value,
        packetCount = connection.packetCount.value,
        telemetry = connection.telemetry.value,
        lastError = connection.error.value,
        log = log.entries.value
    )

    /** Создаёт TXT-отчёт и возвращает Intent «Поделиться». */
    fun buildReportIntent(): Intent? = try {
        val ctx = getApplication<Application>()
        val text = ReportBuilder.build(snapshot())
        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, "kcq_report_$stamp.txt")
        file.writeText(text)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "KCQ CONNECT — диагностический отчёт")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    } catch (e: Exception) {
        log.add("ERROR", "Экспорт отчёта не удался: ${e.message}")
        null
    }

    override fun onCleared() {
        scanner.stop()
        connection.release()
        btMonitor.release()
    }
}
